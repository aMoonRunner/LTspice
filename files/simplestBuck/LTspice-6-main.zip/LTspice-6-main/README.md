# LTspice-6
Files associated to video LTspice #6: Open-Loop Frequency Response of a DC-DC converter

Available at: https://youtu.be/JCHiMp47UGw

How to obtain the open-loop frequency response of a DC-DC converter. Example with a DC-DC buck converter.
